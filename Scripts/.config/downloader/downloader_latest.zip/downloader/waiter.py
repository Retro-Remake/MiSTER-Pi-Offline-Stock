import time
class Waiter:
    def sleep(self, value: float) -> None:
        time.sleep(value)
