import sys
import os
import locale
from pathlib import Path
from typing import Optional
from downloader.config import Environment
from downloader.config_reader import ConfigReader
from downloader.constants import KENV_LOGLEVEL, KENV_LC_HTTP_PROXY, KENV_HTTP_PROXY, KENV_HTTPS_PROXY, \
    KENV_LC_HTTPS_PROXY, KENV_ROTATE_LOGS
from downloader.logger import TopLogger
from downloader.full_run_service_factory import FullRunServiceFactory
def main(env: Environment, start_time: float) -> int:
    locale.setlocale(locale.LC_CTYPE, "")
    logger = TopLogger.for_main(env, start_time)
    logger.bench('MAIN start.')
    try:
        exit_code = execute_full_run(
            FullRunServiceFactory.for_main(logger),
            ConfigReader(logger, env, start_time),
            sys.argv
        )
    except Exception as _:
        import traceback
        logger.print(traceback.format_exc())
        exit_code = 1
    logger.bench('MAIN end.')
    logger.file_logger.finalize()
    return exit_code
def read_env(default_commit: Optional[str]) -> Environment:
    from downloader.constants import DISTRIBUTION_MISTER_DB_ID, DISTRIBUTION_MISTER_DB_URL, DEFAULT_CURL_SSL_OPTIONS, \
    KENV_DOWNLOADER_INI_PATH, KENV_DOWNLOADER_LAUNCHER_PATH, KENV_CURL_SSL, KENV_COMMIT, KENV_ALLOW_REBOOT, \
    KENV_UPDATE_LINUX, KENV_DEFAULT_DB_URL, KENV_DEFAULT_DB_ID, KENV_DEFAULT_BASE_PATH, KENV_DEBUG, \
    KENV_FAIL_ON_FILE_ERROR, KENV_LOGFILE, KENV_PC_LAUNCHER, DEFAULT_UPDATE_LINUX_ENV, KENV_FORCED_BASE_PATH
    return {
        'DOWNLOADER_LAUNCHER_PATH': os.getenv(KENV_DOWNLOADER_LAUNCHER_PATH, None),
        'DOWNLOADER_INI_PATH': os.getenv(KENV_DOWNLOADER_INI_PATH, None),
        'LOGFILE': os.getenv(KENV_LOGFILE, None),
        'LOGLEVEL': os.getenv(KENV_LOGLEVEL, '').lower(),  # info | debug, http
        'CURL_SSL': os.getenv(KENV_CURL_SSL, DEFAULT_CURL_SSL_OPTIONS),
        'COMMIT': os.getenv(KENV_COMMIT, default_commit or 'unknown'),
        'ALLOW_REBOOT': os.getenv(KENV_ALLOW_REBOOT, None),
        'UPDATE_LINUX': os.getenv(KENV_UPDATE_LINUX, DEFAULT_UPDATE_LINUX_ENV).lower(),
        'DEFAULT_DB_URL': os.getenv(KENV_DEFAULT_DB_URL, DISTRIBUTION_MISTER_DB_URL),
        'DEFAULT_DB_ID': os.getenv(KENV_DEFAULT_DB_ID, DISTRIBUTION_MISTER_DB_ID),
        'DEFAULT_BASE_PATH': os.getenv(KENV_DEFAULT_BASE_PATH, None),
        'FORCED_BASE_PATH': os.getenv(KENV_FORCED_BASE_PATH, None),
        'PC_LAUNCHER': os.getenv(KENV_PC_LAUNCHER, None),
        'DEBUG': os.getenv(KENV_DEBUG, 'false').lower(),
        'FAIL_ON_FILE_ERROR': os.getenv(KENV_FAIL_ON_FILE_ERROR, 'false'),
        'HTTP_PROXY': os.getenv(KENV_HTTP_PROXY) or os.getenv(KENV_LC_HTTP_PROXY),
        'HTTPS_PROXY': os.getenv(KENV_HTTPS_PROXY) or os.getenv(KENV_LC_HTTPS_PROXY),
        'ROTATE_LOGS': os.getenv(KENV_ROTATE_LOGS, 'true').lower()
    }
def execute_full_run(full_run_service_factory: FullRunServiceFactory, config_reader: ConfigReader, argv) -> int:
    config = config_reader.read_config(config_reader.calculate_config_path(str(Path().resolve())))
    runner = full_run_service_factory.create(config)
    if len(argv) == 2 and (argv[1] == '--print-drives' or argv[1] == '-pd'):
        exit_code = runner.print_drives()
    else:
        exit_code = runner.full_run()
    return exit_code
