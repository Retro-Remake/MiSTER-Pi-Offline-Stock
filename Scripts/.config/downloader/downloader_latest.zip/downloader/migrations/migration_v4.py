from downloader.store_migrator import MigrationBase
class MigrationV4(MigrationBase):
    version = 4
    def migrate(self, local_store) -> None:
        ""
        wrong_ids = [db_id for db_id, store in local_store['dbs'].items() if db_id.lower() != db_id]
        for db_id in wrong_ids:
            local_store['dbs'][db_id.lower()] = local_store['dbs'].pop(db_id)
