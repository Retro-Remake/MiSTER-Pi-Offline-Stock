from dataclasses import dataclass, field
from downloader.config import ConfigDatabaseSection
from downloader.job_system import Job, JobSystem
from downloader.jobs.load_local_store_sigs_job import LoadLocalStoreSigsJob
from downloader.jobs.transfer_job import TransferJob
@dataclass(eq=False, order=False)
class CheckDbJob(Job):
    type_id: int = field(init=False, default=JobSystem.get_job_type_id())
    transfer_job: TransferJob # Job & Transferrer @TODO: Python 3.10
    section: str
    ini_description: ConfigDatabaseSection
    load_local_store_sigs_job: LoadLocalStoreSigsJob
    def retry_job(self): return self.transfer_job
    skipped: bool = field(default=False)
