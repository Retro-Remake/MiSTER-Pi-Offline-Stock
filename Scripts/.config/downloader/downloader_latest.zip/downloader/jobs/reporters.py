import dataclasses
import threading
import time
from collections import defaultdict
from typing import Dict, Optional, Tuple, List, Set, Type, TypeVar, Generic, Protocol, Union
from downloader.db_entity import DbEntity
from downloader.interruptions import Interruptions
from downloader.jobs.fetch_data_job import FetchDataJob
from downloader.jobs.fetch_file_job import FetchFileJob
from downloader.path_package import PathPackage
from downloader.waiter import Waiter
from downloader.job_system import ProgressReporter, Job
from downloader.logger import Logger
from types import TracebackType
class DownloaderProgressReporter(ProgressReporter):
    def __init__(self, logger: Logger, other_reporters: List[ProgressReporter]) -> None:
        self._logger = logger
        self._other_reporters = other_reporters
        self._failed_jobs: List[Job] = []
    @property
    def failed_jobs(self):
        return [*self._failed_jobs]
    def notify_job_started(self, job: Job) -> None:
        pass
    def notify_work_in_progress(self) -> None:
        for r in self._other_reporters:
            r.notify_work_in_progress()
    def notify_jobs_cancelled(self, _jobs: List[Job]) -> None:
        pass
    def notify_job_completed(self, job: Job, next_jobs: List[Job]) -> None:
        pass
    def notify_job_failed(self, job: Job, exception: BaseException) -> None:
        self._failed_jobs.append(job)
        self._logger.debug(exception)
    def notify_job_retried(self, job: Job, retry_job: Job, exception: BaseException) -> None:
        pass
@dataclasses.dataclass
class ProcessedFolder:
    pkg: PathPackage
    dbs: Set[str]
TJob = TypeVar("TJob", bound=Job)
class InstallationReport(Protocol):
    def get_completed_jobs(self, type_class: Type[TJob]) -> List[TJob]: ""
    def get_started_jobs(self, type_class: Type[TJob]) -> List[TJob]: ""
    def get_failed_jobs(self, type_class: Type[TJob]) ->  List[Tuple[TJob, BaseException]]: ""
    def get_retried_jobs    (self, job_class: Type[TJob]) -> List[Tuple[TJob, BaseException]]: ""
    def get_cancelled_jobs  (self, job_class: Type[TJob]) -> List[TJob]: ""
    def processed_folder(self, path: str) -> Dict[str, PathPackage]: ""
    def all_processed_folders(self) -> List[str]: ""
    def get_jobs_completed_by_tag(self, tag: str) -> List[Job]: ""
    def get_jobs_failed_by_tag(self, tag: str) -> List[Job]: ""
class JobTagTracking:
    def __init__(self) -> None:
        self.in_progress: dict[Union[str, int], set[int]] = defaultdict(set)
        self._initiated: set[int] = set()
        self._ended: set[int] = set()
    def reset(self) -> None:
        self.in_progress.clear()
        self._initiated.clear()
        self._ended.clear()
    def add_job_started(self, job: Job) -> None:
        self._add_job_in_progress(job)
    def add_jobs_cancelled(self, jobs: List[Job]) -> None:
        for job in jobs:
            self._remove_job_in_progress(job)
    def add_job_completed(self, job: Job, next_jobs: List[Job]) -> None:
        auto_spawn = False
        for c_job in next_jobs:
            if c_job == job:
                auto_spawn = True
                continue
            self._reset_lifecycle(c_job)
            self._add_job_in_progress(c_job)
        if not auto_spawn:
            self._remove_job_in_progress(job)
    def add_job_failed(self, job: Job) -> None:
        self._remove_job_in_progress(job)
    def add_job_retried(self, job: Job, retry_job: Job) -> None:
        if job != retry_job:
            self._reset_lifecycle(retry_job)
            self._add_job_in_progress(retry_job)
            self._remove_job_in_progress(job)
    def _add_job_in_progress(self, job: Job) -> None:
        job_id = id(job)
        if job_id not in self._initiated:
            self._initiated.add(job_id)
        if job_id in self._ended:
            return
        for tag in job.tags:
            self.in_progress[tag].add(job_id)
    def _remove_job_in_progress(self, job: Job) -> None:
        job_id = id(job)
        if job_id not in self._ended:
            self._ended.add(job_id)
        if job_id not in self._initiated:
            return
        for tag in job.tags:
            self.in_progress[tag].discard(job_id)
    def _reset_lifecycle(self, job: Job) -> None:
        job_id = id(job)
        self._initiated.discard(job_id)
        self._ended.discard(job_id)
T = TypeVar('T')
class _WithLock(Generic[T]):
    __slots__ = ("data", "lock")
    def __init__(self, data: T, lock: Optional[threading.Lock] = None) -> None:
        self.data = data
        self.lock = lock or threading.Lock()
    def __enter__(self):
        self.lock.acquire()
        return self.data
    def __exit__(self, exc_type: Optional[Type[BaseException]], exc_val: Optional[BaseException], exc_tb: Optional[TracebackType]) -> None:
        self.lock.release()
class InstallationReportImpl(InstallationReport):
    def __init__(self) -> None:
        self._jobs_started: Dict[int, List[Job]] = defaultdict(list)
        self._jobs_completed: Dict[int, List[Job]] = defaultdict(list)
        self._jobs_cancelled: Dict[int, List[Job]] = defaultdict(list)
        self._jobs_failed: Dict[int, List[Tuple[Job, BaseException]]] = defaultdict(list)
        self._jobs_retried: Dict[int, List[Tuple[Job, BaseException]]] = defaultdict(list)
        self._processed_files_set = _WithLock[Set[str]](set())
        self._processed_folders = _WithLock[Dict[str, Dict[str, PathPackage]]]({})
        self._processed_folders_set = _WithLock[Set[str]](set())
        job_tag_lock = threading.Lock()
        self._jobs_tag_tracking = _WithLock[JobTagTracking](JobTagTracking(), job_tag_lock)
        self._jobs_tag_completed = _WithLock[Dict[Union[str, int], List[Job]]](defaultdict(list), job_tag_lock)
        self._jobs_tag_failed = _WithLock[Dict[Union[str, int], List[Job]]](defaultdict(list), job_tag_lock)
    def add_job_started(self, job: Job) -> None:
        self._jobs_started[job.type_id].append(job)
        with self._jobs_tag_tracking as tracking: tracking.add_job_started(job)
    def add_jobs_cancelled(self, jobs: List[Job]) -> None:
        for job in jobs: self._jobs_cancelled[job.type_id].append(job)
        with self._jobs_tag_tracking as tracking: tracking.add_jobs_cancelled(jobs)
    def add_job_completed(self, job: Job, next_jobs: List[Job]) -> None:
        self._jobs_completed[job.type_id].append(job)
        with self._jobs_tag_tracking as tracking:
            tracking.add_job_completed(job, next_jobs)
            for tag in job.tags:
                self._jobs_tag_completed.data[tag].append(job)
    def add_job_failed(self, job: Job, exception: BaseException) -> None:
        self._jobs_failed[job.type_id].append((job, exception))
        with self._jobs_tag_tracking as tracking:
            tracking.add_job_failed(job)
            for tag in job.tags:
                self._jobs_tag_failed.data[tag].append(job)
    def add_job_retried(self, job: Job, retry_job: Job, exception: BaseException) -> None:
        self._jobs_retried[job.type_id].append((job, exception))
        with self._jobs_tag_tracking as tracking: tracking.add_job_retried(job, retry_job)
    def any_in_progress_job_with_tags(self, tags: List[str]) -> bool:
        if len(tags) == 0: return False
        with self._jobs_tag_tracking as tracking:
            for tag in tags:
                if len(tracking.in_progress[tag]) > 0: return True
        return False
    def get_jobs_completed_by_tag(self, tag: str) -> List[Job]:
        with self._jobs_tag_completed as tag_completed:
            return tag_completed[tag]
    def get_jobs_failed_by_tag(self, tag: str) -> List[Job]:
        with self._jobs_tag_failed as tag_failed:
            return tag_failed[tag]
    def add_processed_files(self, files: List[PathPackage]) -> Tuple[List[PathPackage], List[str]]:
        if len(files) == 0: return [], []
        files_set = {pkg.rel_path for pkg in files}
        with self._processed_files_set as processed_files_set:
            duplicates = files_set.intersection(processed_files_set)
            processed_files_set.update(files_set)
        non_duplicates_set = files_set - duplicates
        non_duplicates = [pkg for pkg in files if pkg.rel_path in non_duplicates_set]
        return non_duplicates, list(duplicates)
    def add_processed_folders(self, folders: List[PathPackage], db_id: str) -> List[PathPackage]:
        if len(folders) == 0: return []
        non_already_present = []
        with self._processed_folders as processed_folders:
            for pkg in folders:
                if pkg.rel_path in processed_folders:
                    if db_id in processed_folders[pkg.rel_path]:
                        processed_folders[pkg.rel_path][db_id].description.update(pkg.description)
                    else:
                        processed_folders[pkg.rel_path][db_id] = pkg
                else:
                    non_already_present.append(pkg)
                    processed_folders[pkg.rel_path] = {db_id: pkg}
        return non_already_present
    def get_started_jobs    (self, job_class: Type[TJob]) -> List[TJob]:                        return self._jobs_started   [job_class.type_id]  # type: ignore[return-value, index]
    def get_completed_jobs  (self, job_class: Type[TJob]) -> List[TJob]:                        return self._jobs_completed [job_class.type_id]  # type: ignore[return-value, index]
    def get_failed_jobs     (self, job_class: Type[TJob]) -> List[Tuple[TJob, BaseException]]:  return self._jobs_failed    [job_class.type_id]  # type: ignore[return-value, index]
    def get_retried_jobs    (self, job_class: Type[TJob]) -> List[Tuple[TJob, BaseException]]:  return self._jobs_retried   [job_class.type_id]  # type: ignore[return-value, index]
    def get_cancelled_jobs  (self, job_class: Type[TJob]) -> List[TJob]:                        return self._jobs_cancelled [job_class.type_id]  # type: ignore[return-value, index]
    def processed_folder(self, path: str) -> Dict[str, PathPackage]: return self._processed_folders.data[path]
    def all_processed_folders(self) -> List[str]: return list(self._processed_folders.data.keys())
class FileDownloadSessionLogger(Protocol):
    def print_progress_line(self, line: str) -> None:
        ""
    def print_pending(self) -> None:
        ""
    def print_header(self, db: DbEntity) -> None:
        ""
class FileDownloadSessionLoggerImpl(FileDownloadSessionLogger):
    def __init__(self, logger: Logger, waiter: Waiter) -> None:
        self._logger = logger
        self._waiter = waiter
        self._check_time: float = 0
        self._deactivated: bool = False
        self._needs_newline: bool = False
        self._need_clear_header: bool = False
        self._symbols: List[str] = []
    def _deactivate(self) -> None:
        self._deactivated = True
    def print_job_started(self, job: Job) -> None:
        if isinstance(job, FetchFileJob) and job.db_id is not None:
            self._print_line(job.pkg.rel_path)
        if isinstance(job, FetchDataJob):
            self._logger.bench('FileDownloadSessionLoggerImpl FetchDataJob started: ', job.source)
        self._check_time = time.monotonic() + 2.0
    def print_work_in_progress(self) -> None:
        if self._deactivated:
            return
        now = time.monotonic()
        if self._check_time < now:
            self._symbols.append('*')
            self._print_symbols()
    def print_jobs_cancelled(self, jobs: List[Job]) -> None:
        self._logger.print(f"Cancelled {len(jobs)} jobs.")
    def print_job_completed(self, job: Job, _next_jobs: List[Job]) -> None:
        if isinstance(job, FetchFileJob) and job.db_id is not None:
            self._symbols.append('.')
            if self._needs_newline or self._check_time < time.monotonic():
                self._print_symbols()
        if isinstance(job, FetchDataJob):
            self._logger.bench('FileDownloadSessionLoggerImpl FetchDataJob completed: ', job.source)
    def _print_symbols(self) -> None:
        if len(self._symbols) == 0:
            return
        last_is_asterisk = self._symbols[-1] == '*'
        self._logger.print(('\n' if self._need_clear_header else '') + ''.join(self._symbols), end='')
        self._symbols.clear()
        self._need_clear_header = False
        self._needs_newline = True
        self._check_time = time.monotonic() + (1.0 if last_is_asterisk else 2.0)
    def _print_line(self, line: str) -> None:
        if self._need_clear_header: line = '\n' + line
        if self._needs_newline: line = '\n' + line
        self._logger.print(line)
        self._needs_newline = False
        self._need_clear_header = False
    def print_progress_line(self, line: str) -> None:
        self._print_line(line)
        self._check_time = time.monotonic() + 2.0
    def print_pending(self) -> None:
        self._print_symbols()
        if self._needs_newline:
            self._logger.print()
            self._needs_newline = False
    def print_header(self, db: DbEntity) -> None:
        self._print_symbols()
        first_line = '\n' if self._needs_newline else ''
        self._needs_newline = False
        if len(db.header):
            count_float = 0
            for line in db.header:
                if isinstance(line, float):
                    count_float += 1
            if count_float > 100:
                self._deactivate()
            text = first_line
            for line in db.header:
                if isinstance(line, float):
                    if len(text) > 0:
                        self._logger.print(text)
                        text = ''
                    self._waiter.sleep(line)
                else:
                    text += line
            if len(text) > 0: self._logger.print(text)
        else:
            self._logger.print(
                first_line +
                '################################################################################\n' +
                f'SECTION: {db.db_id}\n'
            )
        self._need_clear_header = True
        self._check_time = time.monotonic() + 2.0
    def print_job_failed(self, job: Job, exception: BaseException) -> None:
        self._print_job_error(job, exception)
    def print_job_retried(self, job: Job, _retry_job: Job, exception: BaseException) -> None:
        self._print_job_error(job, exception)
    def _print_job_error(self, job: Job, exception: BaseException) -> None:
        if isinstance(job, FetchFileJob) and job.db_id is not None:
            self._logger.debug(exception)
            self._symbols.append('~')
            self._print_symbols()
class FileDownloadProgressReporter(ProgressReporter, FileDownloadSessionLogger):
    def __init__(self, logger: Logger, waiter: Waiter, interrupts: Interruptions) -> None:
        self._logger = logger
        self._interrupts = interrupts
        self._session_logger = FileDownloadSessionLoggerImpl(logger, waiter)
        self._report: Optional[InstallationReportImpl] = None
    def installation_report(self) -> InstallationReport: return self._report
    def session_logger(self) -> FileDownloadSessionLogger: return self._session_logger
    def set_installation_report(self, report: InstallationReportImpl):
        self._report = report
    def notify_job_started(self, job: Job) -> None:
        self._report.add_job_started(job)
        self._session_logger.print_job_started(job)
    def notify_work_in_progress(self) -> None:
        self._session_logger.print_work_in_progress()
    def notify_job_completed(self, job: Job, next_jobs: List[Job]) -> None:
        self._report.add_job_completed(job, next_jobs)
        self._session_logger.print_job_completed(job, next_jobs)
    def notify_job_failed(self, job: Job, exception: BaseException) -> None:
        self._report.add_job_failed(job, exception)
        self._session_logger.print_job_failed(job, exception)
    def notify_job_retried(self, job: Job, retry_job: Job, exception: BaseException) -> None:
        self._report.add_job_retried(job, retry_job, exception)
        self._session_logger.print_job_retried(job, retry_job, exception)
    def notify_jobs_cancelled(self, jobs: List[Job]) -> None:
        self._report.add_jobs_cancelled(jobs)
        self._session_logger.print_jobs_cancelled(jobs)
        try:
            self._interrupts.interrupt()
        except Exception as e:
            self._logger.debug(e)
    def print_progress_line(self, line: str) -> None: self._session_logger.print_progress_line(line)
    def print_pending(self) -> None: self._session_logger.print_pending()
    def print_header(self, db: DbEntity) -> None:  self._session_logger.print_header(db)
